let spritesheet;
let spritedata;

//Store frames of the animation
let animation = [];

let spriteSize = 50

//Size ration width/height
let spriteRatio = 192 / 144;

let horses = [];

function preload() {
  spritesheet = loadImage('spritesheet.png');
  spritedata = loadJSON('spritesheet.json');
}

function setup() {
  createCanvas(600, 400);


  //Extract frames object from the sprite sheet
  let frames = Object.values(spritedata.frames);

  //Build the animation
  for (let i = 0; i != frames.length; i++) {
    let frame = frames[i].frame;
    let img = spritesheet.get(frame.x, frame.y, frame.w, frame.h);
    animation.push(img);
  }


  for (let i = 0; i != 10; i++) {
    
    let y = i * spriteSize;
    
    let speed = random(0.1, 0.4);
    
    horses.push(new Sprite(animation, speed, new p5.Vector(10, y), spriteSize, spriteRatio));
  }

}

function draw() {
  background(0);
  for (let horse of horses) {
    horse.show();
    horse.animate();
  }

}