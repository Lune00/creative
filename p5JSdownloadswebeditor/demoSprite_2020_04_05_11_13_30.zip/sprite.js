//Class sprite : contient un tableau de frames pour une animation, une vitesse d'animation, une position

class Sprite {
  constructor(animation, speed, position, size, ratio) {

    this.animation = animation;
    this.position = position;
    this.speed = speed;
    this.indexFrame = 0;
    this.nbFrames = this.animation.length;
    
    //Dimensions:
    
    //Desired size
    this.size = size;
    //Original size ratio (width/height)
    this.ratio = ratio;
  }

  show() {
    let index = floor(this.indexFrame)% this.nbFrames;
    image(this.animation[index], this.position.x, this.position.y, this.size * this.ratio, this.size);
  }

  animate() {
    this.indexFrame += this.speed;
    this.position.x+= this.speed * 5;
    if(this.position.x > width)
      this.position.x = -this.animation[0].width;
  }
}