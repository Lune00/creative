var R = 100 ;
var xCircle  = 200 ;
var yCircle  = 100 ;

function setup() {

  colorMode(HSB);
  createCanvas(400, 400);
 
}

function drawChromaticCircle(){
for (let h = 0; h < 360; h += 4) {
    for (let s = 0; s < R; s+= 4 ) {
      let x = xCircle + s * cos(h * PI / 180);
      let y = yCircle + s * sin(h * PI / 180);
      stroke(h, s, 100);
      strokeWeight(8);
      point(x, y);
    }
  }
}


function distanceToCircleCenter(){
   let myPoint = [ mouseX , mouseY ] ;
   let dxS =  (myPoint[0] - xCircle) * (myPoint[0] - xCircle);
   let dyS =  (myPoint[1] - yCircle) * (myPoint[1] - yCircle);
   return sqrt(dxS + dyS ) ;
}

function mouseInsideCircle(){
   return insideCircle = ( distanceToCircleCenter() < R ) ;
}

function drawColorPicked(){
  
   if ( mouseInsideCircle()) {
     noFill();
     stroke(0,0.4);
     circle(mouseX,mouseY,10);
     // affiche couleur sous le curseur
     stroke(0);
     strokeWeight(1);
     textSize(15);
     fill(255);
     text('Color picked : ', 10 , 300) ;
     text('Complementary color : ', 10 , 330) ;
     text('Analoguous colors : ', 10 , 360) ;
     text('Triadic colors : ', 10 , 390) ;
     text('Tetradic colors : ', 10 , 420) ;
     
     //Get r and theta from x,y
     let r = distanceToCircleCenter();
     let x = mouseX-xCircle ;
     let y = mouseY-yCircle ;
     let theta = 360 - acos(x/r) * 180 / PI ;
     if( y > 0) theta = 360 - theta ;
     
     //Draw color picked
     fill(theta , r ,100);
     //Pour reperer la couleur choisie
     stroke(255);
     square(130,302,-20);
     //Draw complementary color
   }
}

function draw() {
  
   background(0); 
   drawChromaticCircle();
   drawColorPicked();
}