//source : https://thecodingtrain.com/CodingChallenges/033-poisson-disc.html

var r = 50;
var k = 30;
var grid = [];
var w = r / Math.sqrt(2);
var active = [];
var cols, rows;
var ordered = [];


globals = {
  r: 50,
  k: 30,
  w: r / Math.sqrt(2),
  grid: [],
  cols: undefined,
  rows: undefined,
  flowers: [],
  active:[]
}

function initFlowers(){
  
  //STEP 0

  globals.cols = floor(width / w);
  globals.rows = floor(height / w);

  //console.log(cols, rows);

  for (let i = 0; i < cols * rows; i++) {
    grid[i] = undefined;
  }
  
  
}


function setup() {

  createCanvas(400, 400);
  background(0);

  //STEP 0

  cols = floor(width / w);
  rows = floor(height / w);

  //console.log(cols, rows);

  for (let i = 0; i < cols * rows; i++) {
    grid[i] = undefined;
  }


  //STEP 1
  var x = width / 2;
  var y = height / 2;
  var i = floor(x / w);
  var j = floor(y / w);

  var pos = createVector(x, y);
  grid[i + j * cols] = pos;
  active.push(pos);

  
  //for (let total = 0; total < 100; total++) {

    //While loop
    while (active.length > 0) {

      let randIndex = floor(random(active.length));
      let pos = active[randIndex];
      let found = false;

      //Iterate over k samples
      for (let i = 0; i != k; i++) {

        //Generate random point in range [r:2r] around pos (position of the selected 
        //index of activeList
        let sampleVector = p5.Vector.random2D();
        let mag = random(r, 2 * r);
        sampleVector.setMag(mag);
        sampleVector.add(pos);

        let col = floor(sampleVector.x / w);
        let row = floor(sampleVector.y / w);

        //Check new point is in the domain (in a
        //grid cell) and there is not point in the cell 
        //already

        if (
          col >= 0 &&
          col < cols &&
          row >= 0 &&
          row < rows &&
          !grid[col + row * cols]
        ) {

          var ok = true;
          //Check neighbors
          for (let x = -1; x <= 1; x++) {
            for (let y = -1; y <= 1; y++) {
              //Get back 1D grid index
              let index = col + x + (row + y) * cols
              let neighborVector = grid[index];
              if (neighborVector) {

                let d = p5.Vector.dist(sampleVector, neighborVector);
                if (d < r) {
                  ok = false;
                }
              }
            }
          }
          if (ok) {
            found = true;
            grid[col + row * cols] = sampleVector;
            active.push(sampleVector);
            ordered.push(sampleVector);
            //break;
          }
        } //end if in domain && no sample in the cell 
      } //end iterate k points

      if (!found) {
        active.splice(randIndex, 1);
      }

    } //end active empty

  //}
  
  console.log(ordered.length);

}

function draw() {
  
  background(220);
  for (var i = 0; i < ordered.length; i++) {
    if (ordered[i]) {
      stroke(i % 360, 100, 100);
      strokeWeight(r * 0.5);
      point(ordered[i].x, ordered[i].y);
    }
  }
}