//On veut coder un event mouseOver sur un element (circle, square ...)
//Ok, et de effets avec des functions d'easing.
//Enfin on veut dragger les cercles
let t = 0;

const param = {
  defaultRadius: 100,
  amplitude: 20,
  period: 5000,
  phase(){
    return 3 * PI/2;
  }
}

const circles = [];

class Circle {

  constructor(x, y, r) {

    this.x = x;
    this.y = y;
    this.r = r;
    this.strokeWeight = 3;
    this.t = 0;
  }

  show() {
    fill(255);
    strokeWeight(this.strokeWeight);
    circle(this.x, this.y, this.r);
  }

  mouseOver() {
    return dist(mouseX, mouseY, this.x, this.y) < this.r / 2;
  }

  highlight() {
    if (this.mouseOver()) {
      //Radius animation
      this.r = (param.amplitude / 2) * cos(2 * PI * this.t / param.period + param.phase()) + param.defaultRadius;
      this.strokeWeight = 5;
      this.t += deltaTime;

    } else {
      this.t = 0;
      this.strokeWeight = 3;
      this.r = param.defaultRadius;
    }
  }

}



function setup() {
  createCanvas(600, 600);
  initCircles();
  frameRate(30);
}

function highlight() {
  for (let i = 0; i !== circles.length; i++) {
    circles[i].highlight();
  }
}

function initCircles() {

  for (let i = 0; i < 25; i++) {
    circles[i] = new Circle(random(0, 600), random(0, 600), 80);
  }

}

function drawCircles() {

  for (let i = 0; i !== circles.length; i++) {
    circles[i].show();
  }

}

function draw() {

  t += deltaTime;
  background(220);
  drawCircles();
  highlight();
}