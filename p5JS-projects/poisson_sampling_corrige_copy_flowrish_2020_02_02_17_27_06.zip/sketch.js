//source : https://thecodingtrain.com/CodingChallenges/033-poisson-disc.html

const globals = {
  r: 10,
  k: 30,
  w: undefined,
  cols: undefined,
  rows: undefined,
  grid: [],
  flowers: [],
  active: [],
  nbFlowers: 1,
  
  drawFlowers: function() {
    //On peut definir un max a afficher (max <= flowers.length)
    //Quand on gagne de nouvelles couleurs de fleurs on augmente ce max
    //et on repartit les couleurs
    
    if(this.nbFlowers > this.flowers.length)
      this.nbFlowers = this.flowers.length;
    
    
    for (let i = 0; i < this.nbFlowers; i++) {
      if (this.flowers[i]) {
        //stroke(i % 255, 100, 100);
        stroke(255);
        strokeWeight(this.r * 0.5);
        point(this.flowers[i].x, this.flowers[i].y);
      }
    }
  },

  initGrid: function() {
    this.w = this.r / Math.sqrt(2);
    //STEP 0
    this.cols = floor(width / this.w);
    this.rows = floor(height / this.w);
    //console.log(cols, rows);
    for (let i = 0; i < this.cols * this.rows; i++) {
      this.grid[i] = undefined;
    }
  }
}

//CreateCanvas must be called before to init width and height (or call directly dimensions of the web page)
function initSample() {
  
  let x = width / 2;
  let y = height / 2;
  let i = floor(x / globals.w);
  let j = floor(y / globals.w);

  let pos = createVector(x, y);
  globals.grid[i + j * globals.cols] = pos;
  globals.active.push(pos);
}

function makeFlowers() {
  globals.initGrid();
  initSample();
  buildFlowers();
}

function buildFlowers(){
  
  while (globals.active.length > 0) {

    let randIndex = floor( random(globals.active.length) );
    let pos = globals.active[randIndex];

    //Store if a new sample position was found
    let found = false;

    //Iterate over k samples
    for (let i = 0; i != globals.k; i++) {

      //Generate random point in range [r:2r] around pos (position of the selected 
      //index of activeList
      let sampleVector = p5.Vector.random2D();
      let mag = random(globals.r, 2 * globals.r);
      sampleVector.setMag(mag);
      sampleVector.add(pos);

      //col and row of new random sample
      let col = floor(sampleVector.x / globals.w);
      let row = floor(sampleVector.y / globals.w);

      //Check new point is in the domain (in a
      //grid cell) and there is not point in the cell 
      //already
      if ( areColAndRowValidOnGrid(col, row) ) {

        var ok = true;
        //Check neighbors
        for (let x = -1; x <= 1; x++) {
          for (let y = -1; y <= 1; y++) {
            //Get back 1D grid index
            let index = getGridIndexFromRowAndCol(col + x, row + y);
            let neighborVector = globals.grid[index];
            if ( neighborVector ) {

              let d = p5.Vector.dist(sampleVector, neighborVector);
              if (d < globals.r) {
                ok = false;
              }
            }
          }
        }
        if (ok) {
          found = true;
          setGridValueAtColRow(col, row, sampleVector)
          globals.active.push(sampleVector);
          globals.flowers.push(sampleVector);
        }
      } //end if in domain && no sample in the cell 
    } //end iterate k points

    if (!found) {
      globals.active.splice(randIndex, 1);
    }

  } //end active empty 
  
  
  //Shuffle the array 
  //globals.flowers = shuffleArray(globals.flowers);
  
}

function getGridIndexFromRowAndCol(col, row) {
  return col + row * globals.cols;
}

function setGridValueAtColRow(col, row, value) {
  globals.grid[ getGridIndexFromRowAndCol(col, row) ] = value;
}

function areColAndRowValidOnGrid(col, row) {
  return col >= 0 &&
    col < globals.cols &&
    row >= 0 &&
    row < globals.rows &&
    !globals.grid[col + row * globals.cols]
}


function setup() {
  createCanvas(800, 600);
  makeFlowers();
}

function draw() {
  background(0);
  globals.drawFlowers();
  //globals.drawSomeFlowersRandom();
}

//Fisher-Yates (aka Knuth) Shuffle : not in place version
function shuffleArray(array) {
  let currentIndex = array.length;
  let temporaryValue ;
  let randomIndex;

  let shuffledArray = Array.from(array);
  
  // While there remain elements to shuffle...
  while (0 !== currentIndex) {

    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;

    // And swap it with the current element.
    temporaryValue = shuffledArray[currentIndex];
    shuffledArray[currentIndex] = shuffledArray[randomIndex];
    shuffledArray[randomIndex] = temporaryValue;
  }

  return shuffledArray;
}

function mousePressed(){
  globals.nbFlowers+= 100;
}