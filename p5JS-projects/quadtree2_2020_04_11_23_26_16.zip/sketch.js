//2nd implementation : true quadtree
// => four max children (node or point) source: https://jimkang.com/quadtreevis/
// https://gamedevelopment.tutsplus.com/tutorials/quick-tip-use-quadtrees-to-detect-likely-collisions-in-2d-space--gamedev-374

let node;

function setup() {
  createCanvas(800, 600);
  node = new Node(width / 2, height / 2, width / 2, height / 2);
}

function draw() {
  background(0);
  node.show();
  if (mouseIsPressed) {
    node.insert(new Point(mouseX, mouseY));
  }

}

function mousePressed() {

}