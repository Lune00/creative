//Definitions:
//Region : quadrant of a nodes. 4 at total [NW,NE,SW,SE] => [0,1,2,3]

class Node {

  constructor(x, y, w, h, parent) {

    //Rectangular area : x,y position of the center, w,h : half width/height
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;

    //4 children max : either an array of points, either a node
    this.children = [];
    this.children[0] = [];
    this.children[1] = [];
    this.children[2] = [];
    this.children[3] = [];

    //Max children
    this.nChildrenMax = 4;

    //Parent node : Root : no parent . If parent ommited then parent === undefined
    this.parent = parent;
  }


  insert(point) {
    
    //If not in the node
    if (!this.inside(point))
      return;

    //Determines in which region of the node the point is
    let region = this.getRegion(point);

    //Si la region est deja une node enfant il faut inserer dans la node enfant
    if (region instanceof Node) {
      region.insert(point);
      return;
    }
    //Else, Add point to current node
    else {

      //Add the point to the region
      region.push(point);

      //Check if node has reached max capacity (accross all regions) (max nb of children)
      if (this.full()) {

        //We need to subdivise this region where the new point has arrived 
        let childNode = this.getNewNode(this.children.indexOf(region));
        
        //Push points from current node to the child node   
        for(let p of region){
          childNode.insert(p);
        }
        
        //Children point now to the new node
        this.setChildren(this.children.indexOf(region), childNode);
      }
    }
  }
  
  setChildren(index,children){
   this.children[index] = children; 
  }

  inside(point) {
    return point.x > this.x - this.w && point.x < this.x + this.w &&
      point.y > this.y - this.h && point.y < this.y + this.h;
  }


  //Region: 
  //NW = (0,0) == 0
  //NE = (1,0) == 1
  //SW = (0,1) == 2
  //SE = (1,1) == 3
  getRegion(point) {
    let indexX = Math.floor((point.x - (this.x - this.w)) / this.w);
    let indexY = Math.floor((point.y - (this.y - this.h)) / this.h);
    return this.children[indexX + 2 * indexY];
  }

  nbChildren() {
    let n = 0;
    for (let i = 0; i != this.children.length; i++) {
      if (this.children[i] instanceof Node)
        n += 1
      else
        n += this.children[i].length;
    }
    return n;
  }

  nbPoints() {

    let n = 0;
    for (let i = 0; i != this.children.length; i++) {

      if (this.children[i] instanceof Node)
        n += this.children[i].nbPoints();
      else
        n += this.children[i].length;
    }

    return n;
  }


  full() {
    return this.nbChildren() > this.nChildrenMax;
  }


  getNewNode(region) {
    if (region === 0)
      return new Node(this.x - this.w / 2, this.y - this.h / 2, this.w / 2, this.h / 2);
    else if (region === 1)
      return new Node(this.x + this.w / 2, this.y - this.h / 2, this.w / 2, this.h / 2);
    else if (region === 2)
      return new Node(this.x - this.w / 2, this.y + this.h / 2, this.w / 2, this.h / 2);
    else if (region === 3)
      return new Node(this.x + this.w / 2, this.y + this.h / 2, this.w / 2, this.h / 2);
  }



  debug() {
    console.log('show', this.children);
    console.log('nbChildren', this.nbChildren());
    console.log('nbPoints', this.nbPoints());
  }

  show() {

    push();
    rectMode(CENTER);
    strokeWeight(0.2);
    noFill();
    rect(this.x, this.y, 2 * this.w, 2 * this.h);
    pop();

    for (let i = 0; i != this.children.length; i++) {
      if (this.children[i] instanceof Node)
        this.children[i].show();
      else {
        for (let p = 0; p != this.children[i].length; p++) {
          this.children[i][p].show();
        }
      }
    }
  }

}