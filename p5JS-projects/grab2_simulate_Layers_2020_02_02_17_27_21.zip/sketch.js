//SIMULATION DE LAYERS SUR UN CANVAS

//On va simuler des layers avec un layerId

//Selection Ok : Quand on clique sur des elements superposés on prend celui qui a le plus grand
//id (générés a la creation, donc au dessus naturellement visuellement de 
//ceux qui les precedent). Si j'en ai 3 superposés, si je clique sur celui du
//dessus c'est lui que je veux(et c'est bien lui qui a le plus grand id car il
//a été généré apres)

//Quand cet élément est sélectionné on lui attribue l'id le plus grand de la scene, il sera ainsi le plus "haut dans les layers". On voudrait eviter
//que l'ordre dans lequel sont stockées les formes determinent la position
//dans les "layers", comme c'est le cas avec draw par defaut. On ne veut pas de
//cette complexité, a maintenir une liste dans un certain ordre.
//Il faut dessiner les formes non pas en fonction de leur position dans la liste
//mais en fonction de leur layerId. A mediter

//Selection de l'élément au dessus OK, meme quand superposés




//Global : contient tous les éléménts de la scene
const circles = [];

const param = {
  defaultRadius: 100,
  layerIdTopMouseOver: 0
}

class Circle {

  constructor(x, y, r, layerId) {
    this.x = x;
    this.y = y;
    this.r = r;
    this.strokeWeight = 3;
    this.t = 0;
    //Est ce qu'il est selectionné (click maintenu sur lui?)
    this.locked = false;
    //Nouvelles coordonnées apres drag
    this.xOffset = 0;
    this.yOffset = 0;
    //Differentes couleurs: default, select et color est la couleur actuelle
    this.colorDefault = color(189, 51, 255);
    this.colorSelect = color(117, 255, 51);
    this.color = this.colorDefault;
    //Id de layer / Simule le numero de la layer (ie l'ordre dans lequel l'élement
    //est peint sur le canvas). Plus il est grand plus il est sur le top
    this.layerId = layerId;
  }

  show(topElementUnderMouseLayerId) {

    if (this.mouseOver() && this.layerId === topElementUnderMouseLayerId) {
      stroke(51, 219, 255);
    } else {
      stroke(255);
    }

    fill(this.color);
    strokeWeight(this.strokeWeight);
    circle(this.x, this.y, this.r);
  }

  mouseOver() {
    return dist(mouseX, mouseY, this.x, this.y) < this.r / 2;
  }

  //Si on clique dessus alors locked = true;
  //Est cliqué si son layerId correspond a layerId passé en parametre (topest element) sous la souris)
  pressed(topElementUnderMouseLayerId) {
    if (this.mouseOver() && this.layerId === topElementUnderMouseLayerId) {

      this.locked = true;
      this.color = this.colorSelect;

      this.setOffset();

      //Swap: mettre l'element selectionne comme le nouveau topElement (l'amener au front)
      this.bringToTheTop();

    } else {
      this.locked = false;
      this.color = this.colorDefault;
    }

  }

  setOffset() {
    //Garde en mémoire le décalage entre le centre et le point de selection (dragg)
    //de la forme.
    this.xOffset = mouseX - this.x;
    this.yOffset = mouseY - this.y;

  }

  //Put this at the topest layer (premier plan)
  bringToTheTop() {
    let actualCircleTop = getTopElement(circles);
    let temp = this.layerId
    this.layerId = actualCircleTop.layerId;
    actualCircleTop.layerId = temp;

  }

  dragged() {
    if (this.locked) {
      this.x = mouseX - this.xOffset;
      this.y = mouseY - this.yOffset;
      return true;
    }

  }

}





//Retourne layerId maximul d'un element dans la scene
function getMaxLayerId(circles) {
  if (circles.length === 0)
    return null;

  let maxLayerId = circles[0].layerId;

  for (let i = 0; i !== circles.length; i++) {
    maxLayerId = maxLayerId < circles[i].layerId ? circles[i].layerId : maxLayerId;
  }

  return maxLayerId;
}

//Retourne l'élement dans la scene ayant le plus grand layerId
//TODO : a merger avec la fonction setTopElementMouseOver (partie reutilisable
//du code)
function getTopElement(circles) {

  if (circles.length === 0)
    return null;

  let topElementLayerId = getMaxLayerId(circles);

  for (let i = 0; i !== circles.length; i++) {
    if (circles[i].layerId === topElementLayerId) {
      return circles[i];
    }
  }


  return null;
}

function initCircles() {
  for (let i = 0; i < 25; i++) {
    circles[i] = new Circle(random(0, 600), random(0, 600), 80, i);
  }
}

//Render circles on canvas from lowest layerId to higher layerId
//Handle mouseOver event at running
function drawCircles() {

  let circlesMouseOver = [];

  for (let i = 0; i !== circles.length; i++) {
    circles[i].show(param.layerIdTopMouseOver);

    //If mouseOver elements add them to the list
    if (circles[i].mouseOver())
      circlesMouseOver.push(circles[i]);
  }

  //Define selected topElement with mouseOver (ie the more in front)
  setTopElementMouseOver(circlesMouseOver);
}

//Callad once every time the mouse is pressed
function mousePressed() {

  for (let i = 0; i !== circles.length; i++) {
    circles[i].pressed(param.layerIdTopMouseOver);
  }

  //Sort ordre ascendant layerId
  circles.sort(compareLayerId);

  return false;
}

//Compare 2 cercles en fonction de leur layerId
function compareLayerId(circleA, circleB) {
  if (circleA.layerId < circleB.layerId) {
    return -1;
  } else
    return 1;
}


//Called once every time the mouse move and a button is pressed
function mouseDragged() {
  for (let i = 0; i !== circles.length; i++) {
    if (circles[i].dragged())
      console.log("dragged");
  }
}


//set param.layerIdCurrent (gloabal) égal a l'id de l'element de circlesMouseOver
//ayant l'id le plus élevé
const setTopElementMouseOver = (circlesMouseOver) => {
  if (circlesMouseOver.length === 0)
    return;
  param.layerIdTopMouseOver = getMaxLayerId(circlesMouseOver);
};


function setup() {
  frameRate(60);
  createCanvas(600, 600);
  background(0);
  initCircles();
}


function draw() {
  background(0);
  drawCircles();
}




//NOTE: this functions has been merged with main loop drawCircles();
//Function called each frame.
//Si la souris est au dessus d'un element ou plusieurs, trouve l'élément
//du top (i,e avec le plus grand layerId) et appelle setTopElement
//function mouseOver() {
//  let circlesMouseOver = [];
//  for (let i = 0; i !== circles.length; i++) {
//    //Si la souris pointe dessus, prend toutes les formes superposées concernées
//    if (circles[i].mouseOver())
//      circlesMouseOver.push( circles[i]) ;
//  }
//  setTopElementMouseOver(circlesMouseOver);
//}