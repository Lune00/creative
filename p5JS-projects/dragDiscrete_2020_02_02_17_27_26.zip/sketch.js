//Drag & drop une forme sur une grille (position discretes)

//Problems: 
//- layers ! Pas de notion de dessus ou de dessous. SI deux formes
//  se chevauchent alors on selectionne les 2 par defaut
//  utliser createGraphics() pour construire des layers??


// - probleme de bords a fixer (les bordures sortent du canvas)

const globals = {
  nbSquares: 4,
  //Coté d'un carré
  a: 100,
  //Distance entre deux positions discretes sur la "grille" invisible
  gridInterval: 100
}

const squares = [];

class Square {

  constructor(x, y, a, id) {
    //Geometry
    this.x = x;
    this.y = y;
    this.a = a;
    //Est ce qu'il est selectionné (click maintenu sur lui?)
    this.locked = false;

    //Distance entre le centre de la forme et la position du click pour le drag
    this.xOffset = 0;
    this.yOffset = 0;

    //Differentes couleurs: default, select et color est la couleur actuelle
    this.colorDefault = color(189, 51, 255);
    this.colorSelect = color(117, 255, 51);
    this.color = this.colorDefault;
    this.strokeWeight = 2;

    //Identificateur, pour debug
    this.id = id;
  }

  draw() {
    strokeWeight(this.strokeWeight);
    fill(this.color);
    square(this.x, this.y , this.a);
    fill(0);
    textSize(16);
    text(this.id, this.x + this.a / 4, this.y + this.a / 4 );
  }

  //Coordinates of each square is top-left
  mouseOverX() {
    return mouseX > this.x && mouseX < this.x + this.a;
  }

  mouseOverY() {
    return mouseY > this.y && mouseY < this.y + this.a;
  }

  mouseOver() {
    if (this.mouseOverX() && this.mouseOverY())
      return true;
    else
      return false;
  }

  //Quand il est selectionne
  lock() {
    this.strokeWeight = 2;
    this.locked = true;
    this.color = this.colorSelect;
    //Is is really necessary on a grid?
    //Garde en mémoire le décalage entre le centre et le point de selection(dragg)
    //de la forme.
    this.xOffset = mouseX - this.x;
    this.yOffset = mouseY - this.y;
  }

  unlock() {
    this.locked = false;
    this.color = this.colorDefault;
  }

  //Si on clique dessus alors lock() l'element;
  pressed() {
    if ( this.mouseOver() )
      this.lock();
    else
      this.unlock();
  }

  //Quand l'élément est drag
  dragged() {
    if ( this.locked ) {
      this.x = mouseX - this.xOffset;
      this.y = mouseY - this.yOffset;
      return true;
    }
  }

  //Quand la souris est relachée, on lui assigne une position discrete
  released() {
    this.x = round(this.x / globals.gridInterval) * globals.gridInterval;
    this.y = round(this.y / globals.gridInterval) * globals.gridInterval;
    this.unlock();
  }

}

function createSquares() {
  for (let i = 0; i !== globals.nbSquares; i++) {
    squares[i] = new Square(random(0, width/2), random(0, height/2), globals.a, i);
  }
}

function drawSquares() {
  for (let i = 0; i !== globals.nbSquares; i++) {
    squares[i].draw();
  }
}

function setup() {
  createCanvas(800, 600);
  createSquares();
}

//MAIN
function draw() {
  background(220);
  drawSquares();
}

//EVENTS RELATED FUNCTIONS

//Called once every time the mouse is pressed
function mousePressed() {
  for (let i = 0; i !== globals.nbSquares; i++) {
    squares[i].pressed();
  }
  return false;
}

//Called once every time the mouse is released
function mouseReleased() {
  for (let i = 0; i !== globals.nbSquares; i++) {
    if ( squares[i].mouseOver() ) {
      squares[i].released();
    }
  }
  return false;
}

//Called once every time the mouse move and a button is pressed
function mouseDragged() {
  for (let i = 0; i !== globals.nbSquares; i++) {
    squares[i].dragged();
  }
}