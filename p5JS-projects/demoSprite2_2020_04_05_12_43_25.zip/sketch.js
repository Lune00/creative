let player;
let sprite;

function preload() {
  sprite = loadImage('sprite2transp.png');
}

function setup() {
  createCanvas(400, 400);
  player = new Player(width / 2, height / 2, 100, sprite);
}

function draw() {
  background(255);

  player.updateDirection(new p5.Vector(mouseX,mouseY));
  player.move();
  player.show();
  
  circle(0,0,200);

}

function mouseClicked() {

  if(player.isInside(mouseX,mouseY))
    console.log('click on player');

}