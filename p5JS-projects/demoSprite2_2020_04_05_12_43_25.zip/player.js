class Player {
  constructor(x, y, size, sprite) {
    this.x = x;
    this.y = y;
    this.size = size;
    this.sprite = sprite;
    this.tetha = 0 ;
  }

  //Sprite matches hitbox
  show() {
    
    push();
    translate(this.x,this.y);
    rotate(this.tetha);
    image(sprite, -this.size/2, -this.size/2, this.size, this.size);
    pop();
    
  }

  move() {
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += 5;
    }
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= 5;
    }
    
    if (keyIsDown(UP_ARROW)) {
      this.y -= 5;
    }
    
    if (keyIsDown(DOWN_ARROW)) {
      this.y += 5;
    }
  }
  
  updateDirection(pMouse){
    let pos = new p5.Vector(this.x,this.y);
    let dir = p5.Vector.sub(pMouse,pos);
    //angle between -PI and PI (positive clockwise)
    this.tetha = atan2(dir.y, dir.x);
    //console.log(this.tetha * 180/PI);
    
  }
  
  isInside(x,y){
   return (this.x - x)*(this.x - x) + (this.y - y)*(this.y - y) < (this.size/2) * (this.size/2); 
  }

}