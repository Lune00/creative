Store configuration files ( bash, vim, neovim ...)
