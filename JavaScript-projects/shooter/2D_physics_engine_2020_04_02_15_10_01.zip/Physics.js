const Physics = {
  acc: 200,
  vmax: 400,
  vmin: 11, // Stability : vmin > (1/2)(acc/drag)
  drag: 10 // lower the more the drag 
}