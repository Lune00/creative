class Point{
 
  constructor(x,y,data){
    this.x = x;
    this.y = y;
    this.data = data;
  } 
  
  
  show(){
    
    stroke(255);
    strokeWeight(1);
    point(this.x,this.y);
  }
}