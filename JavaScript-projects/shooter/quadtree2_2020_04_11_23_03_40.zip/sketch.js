//2nd implementation : true quadtree
// => four max children (node or point) source: https://jimkang.com/quadtreevis/
// https://gamedevelopment.tutsplus.com/tutorials/quick-tip-use-quadtrees-to-detect-likely-collisions-in-2d-space--gamedev-374

let node;

function setup() {
  createCanvas(400, 400);
  node = new Node(width/2,height/2,width/2,height/2);
}

function draw() {
  background(0);
  node.show();
}

function mousePressed(){
  node.insert(new Point(mouseX,mouseY)); 
  node.debug();
}